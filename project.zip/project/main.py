import sys
import random
import pygame
from  SPRITE import sprite
bg1=pygame.image.load('Sprite-0001.png')
bg2=pygame.image.load('Sprite-0002.png')
bg3=pygame.image.load('Sprite-0003.png')
bg4=pygame.image.load('Sprite-0004.png')
gub_kabob=pygame.image.load('губ кабоб.png')
gub_kabob_rect=gub_kabob.get_rect()
rod=pygame.image.load('rod.png')
rod_rect=rod.get_rect()
rod_rect.centerx=200
rod_rect.centery=350
shop=pygame.image.load('shop.png')
shop_rect=shop.get_rect()
shop_rect.centerx=940
shop_rect.centery=420
quit=[pygame.image.load('yesno1.png'),pygame.image.load('yesno2.png'),pygame.image.load('yesno3.png')]
quit_getrect=quit[0].get_rect()
quit_getrect.centerx=512
quit_getrect.centery=398
gub_kabob_rect.centerx=500
gub_kabob_rect.centery=500
width=1024
height=768
screen=pygame.display.set_mode((width,height))
pygame.mixer.init()
bgs=[bg1,bg2,bg3,bg4]
dude=sprite(screen)
exit=False
text=False
def run():
    pygame.init()
    pygame.display.set_icon(pygame.image.load('рибка.png'))
    pygame.display.set_caption('gub kabob')
    def exit():
        exit=True
        while exit:
            screen.blit(quit[1],quit_getrect)
            pygame.display.flip()
            for i in pygame.event.get():
                if i.type==pygame.MOUSEBUTTONDOWN:
                    if i.pos[0]>300 and i.pos[0]<480 and i.pos[1]>385 and i.pos[1]<430:
                        if i.button==1:
                            screen.blit(quit[0],quit_getrect)
                            pygame.display.flip()
                            pygame.time.delay(500)
                            sys.exit()
                    elif i.pos[0]>540 and i.pos[0]<725 and i.pos[1]>385 and i.pos[1]<430:
                        if i.button==1:
                            screen.blit(quit[2],quit_getrect)
                            pygame.display.flip()
                            pygame.time.delay(500)
                            exit=False

    def events():
        for bg in bgs:
            i=0
            while i<500:
                for ii in pygame.event.get():
                    if ii.type == pygame.QUIT:
                        exit()
                    elif ii.type==pygame.KEYDOWN:
                        if ii.key==pygame.K_d:
                            dude.move_r=True
                            dude.move_l=False
                            dude.fishing=False
                            dude.shopping =False
                        if ii.key==pygame.K_a:
                            dude.move_l = True
                            dude.move_r = False
                            dude.fishing=False
                            dude.shopping=False
                        if ii.key==pygame.K_s:
                            dude.move_d=True
                            dude.move_up=False
                            dude.fishing=False
                            dude.shopping =False
                        if ii.key==pygame.K_w:
                            if dude.image_getrect.top == 390:
                                dude.fishing=True
                            if dude.image_getrect.top>=465 and dude.image_getrect.right <=975 and dude.image_getrect.left>=880:
                                dude.shopping = True
                            dude.move_up = True
                            dude.move_d = False
                        if ii.key==pygame.K_q:
                            pass
                    elif ii.type==pygame.KEYUP:
                        if ii.key==pygame.K_d:
                            dude.rotate_r=True
                            dude.move_l=False
                            dude.move_r=False
                            dude.rotate_l=False
                        if ii.key==pygame.K_a:
                            dude.rotate_r=False
                            dude.move_r=False
                            dude.move_l=False
                            dude.rotate_l=True
                        if ii.key == pygame.K_s:
                            dude.move_d=False
                            dude.move_up=False
                            dude.stare_d=True
                            dude.stare_up=False
                            dude.rotate_r=False
                            dude.rotate_l=False
                        if ii.key == pygame.K_w:
                            if dude.image_getrect.top==390:
                                dude.fishing=True
                            if dude.image_getrect.top==465 and dude.image_getrect.right<=970 and dude.image_getrect.left>=800:
                                dude.shopping=True
                            dude.move_up=False
                            dude.move_d=False
                            dude.stare_up=True
                            dude.stare_d=False
                            dude.rotate_r=False
                            dude.rotate_l=False
                        if ii.key==pygame.K_q:
                            pass
                dude.dude()
                dude.update(i)
                screen.blit(bg,screen.get_rect())
                if dude.fishing:
                    screen.blit(rod,rod_rect)
                if dude.shopping:
                    screen.blit(shop,shop_rect)
                if i//250==0 or i%200==0:
                    screen.blit(dude.pos,dude.image_getrect)
                else:screen.blit(dude.pos2, dude.image_getrect)
                i+=1
                pygame.display.flip()
    while True:
        events()
run()

