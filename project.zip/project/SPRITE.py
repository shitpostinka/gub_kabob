import sys
import pygame

class sprite():
    def __init__(self,x):
        self.screen=x
        self.screen_rect=x.get_rect()
        self.image=pygame.image.load('челик.png')
        self.image2=pygame.image.load('челик профиль.png')
        self.image3=pygame.transform.flip(self.image2,True,False)
        self.image4=pygame.image.load('челик шагает.png')
        self.image5=pygame.transform.flip(self.image4,True,False)
        self.image6=pygame.image.load('челик вперед.png')
        self.image7=pygame.image.load('челик вперед зеркалка.png')
        self.image8=pygame.image.load('челик сзади.png')
        self.image9=pygame.image.load('челик назад.png')
        self.image10=pygame.image.load('челик назад зеркалка.png')
        self.image11=pygame.image.load('челик рыбачит.png')
        self.image_getrect=self.image.get_rect()
        self.image_getrect.centerx=980
        self.image_getrect.centery=560
        self.move_r=False
        self.move_l=False
        self.move_up=False
        self.move_d=False
        self.rotate_r=False
        self.rotate_l=False
        self.stare_up=False
        self.stare_d=False
        self.fishing=False
        self.shopping=False
    def update(self,x):
        if x%3==0 or x%5==0:
            if self.move_up:
                if self.image_getrect.top<500 and ((self.image_getrect.right>590 and self.image_getrect.right<880) or (self.image_getrect.right>975)):
                    self.image_getrect.centery+=0
                elif self.image_getrect.top>390 and self.image_getrect.right<280 and self.image_getrect.left>80:
                    self.image_getrect.centery-=1
                elif self.image_getrect.top>465 and (self.image_getrect.right>=280 or self.image_getrect.left<=80):
                    self.image_getrect.centery-=1
            if self.move_d and self.image_getrect.right>=0 and self.image_getrect.left<=1024 and self.image_getrect.bottom<=600:
                self.image_getrect.centery+=1
            if self.move_l and self.image_getrect.left>0:
                if self.image_getrect.top>=465 and (self.image_getrect.right>280 or self.image_getrect.left<=80):
                    self.image_getrect.centerx-=1
                if self.image_getrect.top>=390 and self.image_getrect.right<=280 and self.image_getrect.left>80:
                    self.image_getrect.centerx-=1
                if self.image_getrect.top<490 and self.image_getrect.right>590:
                    self.image_getrect.centerx+=1
            if self.move_r and self.image_getrect.right<1024:
                if self.image_getrect.top<490 and self.image_getrect.right>590:
                    self.image_getrect.centerx+=0
                elif self.image_getrect.top>=465 and (self.image_getrect.right>=280 or self.image_getrect.left<80):
                    self.image_getrect.centerx+=1
                elif self.image_getrect.top>=390 and self.image_getrect.right<280 and self.image_getrect.left>=80:
                    self.image_getrect.centerx+=1
    def dude(self):
        if self.fishing:
            self.pos=self.image8
            self.pos2=self.image8
        elif self.move_r:
            self.pos=self.image3
            self.pos2=self.image5
        elif self.move_l:
            self.pos=self.image2
            self.pos2=self.image4
        elif self.move_d:
            self.pos=self.image6
            self.pos2=self.image7
        elif self.move_up:
            self.pos=self.image9
            self.pos2=self.image10
        elif self.rotate_r:
            self.pos=self.image3
            self.pos2=self.image3
        elif self.rotate_l:
            self.pos=self.image2
            self.pos2=self.image2
        elif self.stare_up:
            self.pos=self.image8
            self.pos2=self.image8
        elif self.stare_d:
            self.pos=self.image
            self.pos2=self.image
        else:
            self.pos=self.image
            self.pos2=self.image
